#ifndef FORMFIRE_H
#define FORMFIRE_H

#include <QWidget>
#include <QChartView>
#include <QLineSeries>
#include <QValueAxis>
#include <QTimer>
/*  必需添加命名空间 */
QT_CHARTS_USE_NAMESPACE
namespace Ui {
class FormFire;
}

class FormFire : public QWidget
{
    Q_OBJECT

public:
    explicit FormFire(QWidget *parent = nullptr);
    ~FormFire();

private slots:
    void timerTimeOut();

private:
    QLineSeries *line_1;  //温度第一条线

    QLineSeries *line_2;

    QLineSeries *line_3;
    Ui::FormFire *ui;
};

#endif // FORMFIRE_H
